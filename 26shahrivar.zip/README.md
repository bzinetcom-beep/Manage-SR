# 🛡️ SRMS — سامانه مدیریت منابع سرباز

> **Soldier Resource Management System**
> Next.js 16 (App Router) · React 19 · PostgreSQL + Drizzle ORM · Tailwind CSS 4 · TypeScript

سامانه‌ای کامل برای ثبت، مدیریت، گزارش‌گیری و **تولید انبوه نامه** برای سربازان؛ به‌همراه
**ماژول بروزرسانی خودکار**، **پشتیبان‌گیری/بازیابی کامل**، **نصاب ویزاردی ویندوز با سازوکار خودترمیم**،
داشبورد آماری، اعلان‌های هوشمند، وارد/خروج اکسل و چاپ اسناد.

---

## 📑 فهرست

1. [تکنولوژی‌ها](#1-تکنولوژیها)
2. [ساختار پروژه](#2-ساختار-پروژه)
3. [پیش‌نیازها](#3-پیشنیازها)
4. [راه‌اندازی سریع (توسعه)](#4-راهاندازی-سریع-حالت-توسعه)
5. [اجرای مرحله‌به‌مرحله در حالت توسعه](#5-اجرای-مرحلهبهمرحله-در-حالت-توسعه)
6. [اجرای مرحله‌به‌مرحله در حالت پروداکشن](#6-اجرای-مرحلهبهمرحله-در-حالت-پروداکشن)
7. [نصاب ویزاردی ویندوز (خودترمیم)](#7-نصاب-ویزاردی-ویندوز-با-سازوکار-خودترمیم)
8. [سازوکار بروزرسانی سامانه](#8-سازوکار-بروزرسانی-سامانه)
9. [پشتیبان‌گیری و بازیابی](#9-پشتیبانگیری-و-بازیابی)
10. [ماژول تولید انبوه نامه](#10-ماژول-تولید-انبوه-نامه)
11. [متغیرهای محیطی](#11-متغیرهای-محیطی)
12. [حل مشکلات رایج](#12-حل-مشکلات-رایج)

---

## 1. تکنولوژی‌ها

| لایه | تکنولوژی |
|---|---|
| فریم‌ورک | **Next.js 16** (App Router, Route Handlers, Turbopack/Webpack) |
| رابط کاربری | **React 19** + **Tailwind CSS 4** + lucide-react + recharts |
| زبان | TypeScript 5 (strict) |
| پایگاه‌داده | **PostgreSQL 14+** با **Drizzle ORM 0.45** |
| احراز هویت | JWT (jose) در کوکی HttpOnly + middleware |
| سند/چاپ | jsPDF, html2canvas-pro, jszip, mammoth (وارد کردن قالب Word) |
| اکسل | xlsx (SheetJS) |
| رومیزی (اختیاری) | Electron + PGlite (پایگاه‌داده داخلی) |

---

## 2. ساختار پروژه

```
SRMS/
├─ src/
│  ├─ app/
│  │  ├─ (app)/                 # صفحات اصلی (داشبورد، سربازان، نامه‌ها، گزارش‌ها…)
│  │  │  ├─ dashboard/  letters/  soldiers/  reports/  imports/  settled/
│  │  │  ├─ settings/           # فیلدهای پویا، قوانین اعلان
│  │  │  │  └─ backup/          # 💾 پشتیبان‌گیری و بازیابی (جدید)
│  │  │  ├─ updates/            # 🚀 بروزرسانی سامانه
│  │  │  └─ users/  notifications/
│  │  ├─ api/                   # REST API (route handlers)
│  │  │  ├─ letters/            # generate | recipients | import-excel | docx | [id]
│  │  │  ├─ backups/            # 🔹 list | settings | [id] | restore  (جدید)
│  │  │  ├─ updates/            # apply | rollback | version | sample
│  │  │  └─ soldiers/  reports/  users/  auth/  ai/ …
│  │  ├─ documents/             # صفحات چاپ اسناد
│  │  └─ login/
│  ├─ components/
│  │  ├─ letters/               # GenerateTab, TemplatesTab, LettersTab
│  │  │  └─ LetterVisualEditor.tsx   # ✍️ ویرایشگر گرافیکی (WYSIWYG) — جدید
│  │  └─ Sidebar | TopBar | Chatbot | …
│  ├─ db/                       # schema.ts | index.ts | init-db.ts
│  ├─ lib/                      # منطق اصلی
│  │  ├─ letter-engine.ts       # موتور قالب و جای‌نگهدار
│  │  ├─ service-status.ts      # وضعیت خدمت (در حال خدمت / تسویه‌شده)
│  │  ├─ updates.ts             # موتور بروزرسانی و Rollback
│  │  ├─ backup.ts              # 💾 موتور پشتیبان‌گیری/بازیابی — جدید
│  │  └─ backup-scheduler.ts    # ⏱ زمان‌بند پشتیبان خودکار — جدید
│  └─ instrumentation.ts        # راه‌اندازی زمان‌بند هنگام بوت سرور — جدید
├─ scripts/
│  ├─ backup.mjs  restore.mjs   # پشتیبان/بازیابی از خط فرمان — جدید
│  ├─ build-update.mjs          # ساخت خودکار فایل بروزرسانی — جدید
│  ├─ embedded-pg.mjs           # پایگاه‌داده داخلی آفلاین — جدید
│  └─ seed*.mjs  fix-*.mjs  setup-and-start.ps1
├─ installer/
│  ├─ SRMS-Setup-Wizard.bat     # نصاب ویزاردی ویندوز — جدید
│  ├─ wizard.ps1                # منطق نصب + خودترمیم — جدید
│  └─ README.md
├─ updates/                     # بسته‌های بروزرسانی (.srms-update)
├─ backups/                     # محل پیش‌فرض فایل‌های پشتیبان
├─ SRMS-Start.bat / Start-Dev.bat / SRMS-Repair.bat / SRMS-Backup-Now.bat
└─ next.config.ts  drizzle.config.json  tsconfig.json
```

---

## 3. پیش‌نیازها

| ابزار | نسخه | توضیح |
|---|---|---|
| **Node.js** | **22 LTS** (حداقل 20) | `node -v` |
| **npm** | 10+ | همراه Node |
| **PostgreSQL** | 14+ | `psql --version` — یا از پایگاه‌داده داخلی استفاده کنید |
| ویندوز | 10/11 (64-bit) | برای نصاب ویزاردی |

> اگر PostgreSQL ندارید: `node scripts/embedded-pg.mjs` یک سرور PostgreSQL کامل و آفلاین
> داخل پوشه `data/pglite` اجرا می‌کند (بدون نصب سرویس روی ویندوز).

---

## 4. راه‌اندازی سریع (حالت توسعه)

```bash
# ۱) نصب پکیج‌ها
npm install

# ۲) فایل محیطی
#    ویندوز (PowerShell):
Set-Content .env "DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db"
#    لینوکس/مک:
echo "DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db" > .env

# ۳) ساخت جدول‌ها
npx drizzle-kit push

# ۴) اجرا
npm run dev          # → http://localhost:3000
```

**ورود پیش‌فرض** (در اولین اجرا به‌صورت خودکار ساخته می‌شوند):

| نام کاربری | رمز عبور | نقش |
|---|---|---|
| `admin` | `admin123` | مدیر سیستم (کامل) |
| `operator` | `operator123` | ثبت اطلاعات |
| `viewer` | `viewer123` | فقط مشاهده |

> ⚠️ پس از اولین ورود، رمز کاربر `admin` را از صفحه «مدیریت کاربران» تغییر دهید.

---

## 5. اجرای مرحله‌به‌مرحله در حالت توسعه

### گام ۱ — پیش‌نیاز
```bash
node -v      # باید v20 یا بالاتر باشد (پیشنهادی v22)
npm -v
psql --version
```

### گام ۲ — ساخت پایگاه‌داده
```bash
# ویندوز (PowerShell)
$env:PGPASSWORD="postgres"
psql -U postgres -c "CREATE DATABASE app_db;"

# لینوکس/مک
createdb -U postgres app_db
```
> اگر پایگاه‌داده ساخته نشود هم مشکلی نیست؛ برنامه در اولین اجرا جدول‌ها را
> به‌صورت خودکار می‌سازد (`src/db/init-db.ts` — bootstrap بدون خطا).

### گام ۳ — فایل `.env`
```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
```

### گام ۴ — نصب وابستگی‌ها
```bash
npm install
```

### گام ۵ — هم‌گام‌سازی اسکیمای Drizzle
```bash
npx drizzle-kit push
```

### گام ۶ — اجرای سرور توسعه
```bash
npm run dev
```
سپس مرورگر را روی `http://localhost:3000` باز کنید.

### گام ۷ — (اختیاری) داده نمونه
```bash
node scripts/seed.mjs         # چند رکورد نمونه
node scripts/seed-1000.mjs    # ۱۰۰۰ سرباز نمونه
```

### ویندوز — یک کلیک
```bat
Start-Dev.bat
```
این فایل `scripts/setup-and-start.ps1 -DevMode` را اجرا می‌کند که همه‌ی گام‌های بالا
را خودکار انجام می‌دهد.

---

## 6. اجرای مرحله‌به‌مرحله در حالت پروداکشن

### گام ۱ — تنظیم محیط
```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
NODE_ENV=production
NEXT_TELEMETRY_DISABLED=1
```
> کلید امضای JWT به‌صورت خودکار در فایل `.srms-secret` ساخته و نگه‌داری می‌شود
> (یا از متغیر `AUTH_SECRET` با طول ۳۲ کاراکتر به بالا استفاده کنید).

### گام ۲ — نصب پکیج‌ها
```bash
npm ci          # نصب دقیقاً بر اساس package-lock.json (توصیه‌شده)
# یا
npm install --omit=dev=false
```

### گام ۳ — ساخت جدول‌ها
```bash
npx drizzle-kit push
```

### گام ۴ — ساخت نسخه پروداکشن
```bash
npm run build
```

### گام ۵ — اجرای سرور
```bash
npm run start                 # پورت ۳۰۰۰
# یا با پورت دلخواه:
npx next start -p 8080
```

### گام ۶ — بررسی سلامت
```bash
curl http://localhost:3000/api/health
```

### گام ۷ — اجرای دائمی به‌عنوان سرویس

**ویندوز (Task Scheduler):**
```bat
schtasks /Create /TN "SRMS Server" /SC ONSTART /RU SYSTEM ^
  /TR "cmd /c cd /d D:\SRMS && npm run start >> logs\server.log 2>&1"
```

**لینوکس (systemd):**
```ini
# /etc/systemd/system/srms.service
[Unit]
Description=SRMS
After=network.target postgresql.service

[Service]
WorkingDirectory=/opt/srms
Environment=NODE_ENV=production
Environment=PORT=3000
ExecStart=/usr/bin/npm run start
Restart=always

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl enable --now srms
```

### ویندوز — یک کلیک (توصیه‌شده)
```bat
installer\SRMS-Setup-Wizard.bat     :: نصب کامل + اجرا
SRMS-Start.bat                      :: اجرای بعدی
```

---

## 7. نصاب ویزاردی ویندوز با سازوکار خودترمیم

فایل `installer\SRMS-Setup-Wizard.bat` را دابل‌کلیک کنید. ویزارد **۹ مرحله** را انجام می‌دهد:

1. بررسی فایل‌های پروژه
2. بررسی/نصب **Node.js** (آفلاین → winget → choco → دانلود MSI)
3. بررسی/راه‌اندازی **PostgreSQL** (سرویس خاموش → استارت → تست رشته‌های اتصال → **پایگاه‌داده داخلی**)
4. نوشتن تنظیمات (`.env`, `drizzle.config.json`, پورت، مسیر پشتیبان)
5. نصب پکیج‌ها (۴ مسیر جایگزین در صورت خطا)
6. ساخت جدول‌های پایگاه‌داده
7. ساخت نسخه پروداکشن (پاک‌سازی کش → webpack → افزایش حافظه)
8. میانبر دسکتاپ + **وظیفه پشتیبان‌گیری روزانه** + قانون فایروال
9. اجرای سامانه و بررسی سلامت با تلاش مجدد

**خودترمیم:** هر مرحله در `Invoke-HealingStep` اجرا می‌شود؛ در صورت خطا تابع ترمیم همان مرحله
اجرا و تا ۳ بار تلاش می‌شود. **هیچ خطایی نصب را لغو نمی‌کند** و در پایان، فهرست هشدارها و
ترمیم‌های خودکار نمایش داده می‌شود. لاگ کامل: `srms-install.log`.

جزئیات کامل: [`installer/README.md`](installer/README.md)

---

## 8. سازوکار بروزرسانی سامانه

هر تغییر در سامانه همراه با یک **فایل بروزرسانی** (`.srms-update`) ارائه می‌شود که از صفحه
«🚀 بروزرسانی سامانه» قابل آپلود است.

### ویژگی‌ها
- اعمال تغییرات پایگاه‌داده **در یک تراکنش** (خطا = بازگشت کامل)
- ثبت **Snapshot** از وضعیت قبلی تنظیمات/فیلدها/قوانین/فایل‌ها
- **Rollback یک‌کلیکه** به آخرین نسخه یا هر نسخه دلخواه
- ثبت تاریخچه‌ی کامل نسخه‌ها و نمایش تغییرات (changelog)

### ساخت خودکار فایل بروزرسانی
```bash
node scripts/build-update.mjs                     # نسخه بعدی (minor)
node scripts/build-update.mjs 1.5.0 changes.txt   # نسخه مشخص + فهرست تغییرات
```
خروجی در `updates/srms-update-v<version>.srms-update` ذخیره می‌شود.

### نسخه‌های موجود
| فایل | محتوا |
|---|---|
| `srms-update-v1.1.0.srms-update` | نسخه اولیه موتور بروزرسانی |
| `srms-update-v1.2.0.srms-update` | بهبودهای موتور نامه و اعلان‌ها |
| `srms-update-v1.3.0.srms-update` | بهبود گزارش‌ها و ایمپورت اکسل |
| `srms-update-v1.4.0.srms-update` | **ویرایشگر گرافیکی نامه + فیلتر سربازان در حال خدمت + ماژول پشتیبان‌گیری** |

مستندات کامل: [`updates/README.md`](updates/README.md)

---

## 9. پشتیبان‌گیری و بازیابی

### ۹-۱) از داخل برنامه (توصیه‌شده)
مسیر: **⚙️ تنظیمات → 💾 پشتیبان‌گیری و بازیابی**

- **محل ذخیره قابل انتخاب**: مسیر نسبی (`backups`) یا مسیر مطلق ویندوز (`D:\SRMS-Backups`)
- **پشتیبان‌گیری خودکار**: ساعتی/روزانه/هفتگی + ساعت اجرا + روز هفته
- **نگهداری نسخه‌ها**: تعداد مشخص (پاک‌سازی خودکار نسخه‌های قدیمی)
- **دستی**: دکمه «تهیه نسخه پشتیبان الآن»
- **بازیابی**: از فهرست نسخه‌ها یا با آپلود فایل `.srms-backup`
  (پیش از بازیابی، یک **نسخه اطمینان** از وضعیت فعلی گرفته می‌شود)

### ۹-۲) از خط فرمان (برای Task Scheduler)
```bash
node scripts/backup.mjs "D:\SRMS-Backups" scheduled     # تهیه نسخه
node scripts/restore.mjs "D:\SRMS-Backups\srms-backup-....srms-backup" --yes
```

### ۹-۳) با یک دابل‌کلیک
```bat
SRMS-Backup-Now.bat
```

### فرمت فایل پشتیبان
```
{
  "format": "srms-backup",
  "formatVersion": 1,
  "appVersion": "1.4.0",
  "createdAt": "ISO-8601",
  "tableCounts": { "soldiers": 1200, "letters": 340, ... },
  "schema":     { "<table>": [ { name, dataType }, ... ] },
  "tables":     { "<table>": [ { col: value, ... }, ... ] }
}
```
بازیابی در یک **تراکنش** انجام می‌شود و شمارنده‌های `SERIAL` نیز اصلاح می‌شوند؛ بنابراین
سامانه دقیقاً به آخرین وضعیت سالم قبل از خرابی برمی‌گردد.

### زمان‌بند خودکار
`src/instrumentation.ts` هنگام بالا آمدن سرور، `backup-scheduler.ts` را فعال می‌کند که هر
**۱۰ دقیقه** بررسی می‌کند آیا زمان پشتیبان‌گیری طبق تنظیمات رسیده است یا نه.

---

## 10. ماژول تولید انبوه نامه

### مراحل کار (ویزارد ۴ مرحله‌ای)
1. **انتخاب قالب** — قالب‌های سیستمی/سفارشی یا وارد کردن قالب Word
2. **انتخاب گیرندگان**
   - به‌صورت **پیش‌فرض فقط سربازان «در حال خدمت»** نمایش داده می‌شوند
   - فیلتر: `در حال خدمت` | `تسویه‌شده` | `همه`
   - فیلترهای یگان، درجه و جستجوی نام/کد ملی
   - **آپلود فایل اکسل سربازان دلخواه** (تطبیق با کد ملی/شماره پرسنلی/نام؛ ستون‌های اضافی
     به‌عنوان مقدار اختصاصی همان نفر در نامه درج می‌شوند)
3. **تکمیل اطلاعات** — شماره‌گذاری نامه‌ها، عنوان دسته، مقادیر مشترک
4. **پیش‌نمایش و ویرایش گرافیکی**
   - **پیش‌نمایش کاغذی** A4/A5 با بزرگ‌نمایی
   - **ویرایش گرافیکی متن** (WYSIWYG شبیه Word): فونت، اندازه، رنگ، هایلایت، تراز،
     فهرست، جدول، خط جداکننده، واگرد/ازنو — **بدون دیدن کد HTML**
   - درج داده سرباز به‌صورت **تراشه** (chip) با یک کلیک
   - امکان **ویرایش اختصاصی متن نامه‌ی یک سرباز** در میان دسته انبوه
   - امکان ذخیره‌ی ویرایش روی خود قالب

### جای‌نگهدارها
```
{{نام}} {{نام_خانوادگی}} {{کد_ملی}} {{درجه}} {{یگان}} {{پایان_خدمت}} …
{{شماره_نامه}} {{تاریخ_نامه}} {{تاریخ_امروز}} {{ردیف}}
```
هر واژه‌ی دلخواه دیگری (مثلاً `{{مبلغ_کمک_هزینه}}`) به‌صورت خودکار پارامتر ورودی در
مرحله ۳ شناخته می‌شود.

---

## 11. متغیرهای محیطی

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `DATABASE_URL` | `postgresql://postgres:postgres@127.0.0.1:5432/app_db` | رشته اتصال PostgreSQL |
| `AUTH_SECRET` | ساخت خودکار در `.srms-secret` | کلید امضای JWT (≥۳۲ کاراکتر) |
| `PORT` | `3000` | پورت سرور |
| `SRMS_BACKUP_DIR` | `backups` | مسیر پیش‌فرض پشتیبان‌ها |
| `SRMS_EMBEDDED_PG_PORT` | `55432` | پورت پایگاه‌داده داخلی |
| `NEXT_TELEMETRY_DISABLED` | `1` | غیرفعال‌سازی تله‌متری |

---

## 12. حل مشکلات رایج

| مشکل | راه‌حل |
|---|---|
| صفحه سفید / خطای ۵۰۰ | `SRMS-Repair.bat` یا: حذف `.next` و اجرای `npm run build` |
| `Failed to load external module pg-...` | `node scripts/fix-turbopack-externals.mjs` سپس ساخت مجدد |
| خطای اتصال پایگاه‌داده | سرویس PostgreSQL را استارت کنید یا `node scripts/embedded-pg.mjs` را اجرا کنید |
| پورت ۳۰۰۰ اشغال است | `npx next start -p 3001` |
| فراموشی رمز مدیر | `psql $DATABASE_URL -c "delete from users where username='admin'"` سپس اجرای مجدد برنامه |
| نصب پکیج‌ها با خطا مواجه شد | `npm cache verify` سپس حذف `node_modules` و `npm install --legacy-peer-deps` |
| حافظه کم هنگام build | `$env:NODE_OPTIONS="--max-old-space-size=4096"` سپس `npm run build` |

---

## اسکریپت‌های npm

| دستور | کار |
|---|---|
| `npm run dev` | اجرای سرور توسعه |
| `npm run build` | ساخت نسخه پروداکشن |
| `npm run start` | اجرای نسخه پروداکشن |
| `npm run lint` | بررسی کیفیت کد |
| `npm run typecheck` | بررسی تایپ‌ها |

---

## نسخه فعلی سامانه

**1.4.0** — ویرایشگر گرافیکی نامه، فیلتر سربازان در حال خدمت در انتخاب گیرندگان،
ماژول پشتیبان‌گیری/بازیابی با زمان‌بند خودکار، نصاب ویزاردی خودترمیم ویندوز،
README کامل و سازنده‌ی خودکار بسته‌های بروزرسانی.
